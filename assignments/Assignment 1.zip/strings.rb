# Assigns the string to the variable kayne_quote. The "\" breaks the string up into seperate lines in the editor to provide a cleaner looking code.
kayne_quote = "My greatest pain in life \
id that I will never be able \
to see myself perform live."

# Assigns the string to the variable hamilton_quote. The "\" in this case allows for the usage of quotation marks inside of the string.
hamilton_quote = "Well, the word got around, they said, \"This kid's insane, man\""

# Prints the string stored to the variable hamilton_quote to a new line.
puts hamilton_quote
