# Assigns the interger 200 to the variable orphan_fee.
orphan_fee = 200
# Assigns the float 121.08 to the variable teddy_bear_fee.
teddy_bear_fee = 121.08

# Assigns the sum of the variables orphan_fee and teddy_bear_fee to the variable total.
total = orphan_fee + teddy_bear_fee

# Assigns the string to the variable name.
name = "James Garvey"

# Prints the string to a new line with the variables name and total interpolated in.
puts "#{name}, the total will be $#{total}."
